// CONSTANTS
const API_LOGIN 		= "user/login";
const API_LOGOUT		= "user/logout";
const API_USER_GET 		= "user/get";
const API_USER_UPDATE	= "user/update";

const LANG = {
	"BAD_CREDENTIALS" : "Incorrect username or password."
}
// CONSTANTS